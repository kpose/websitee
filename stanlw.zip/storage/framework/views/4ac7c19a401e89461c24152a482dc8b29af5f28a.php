<!-- Footer Starts -->
<div class="footer navbar-fixed-bottom" style="background-color:#000" >
     Copyright 2017 primearners.   Designed By softloft
   </div>

<!-- # Footer Ends -->
