<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>FASTALERT</title>

<!-- Google fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>

<!-- font awesome -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

<!-- bootstrap -->
<link rel="stylesheet" href="asset/bootstrap/css/bootstrap.min.css" />

<!-- animate.css -->
<link rel="stylesheet" href="asset/animate/animate.css" />
<link rel="stylesheet" href="asset/animate/set.css" />

<!-- gallery -->
<link rel="stylesheet" href="asset/gallery/blueimp-gallery.min.css">

<!-- favicon -->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">


<link rel="stylesheet" href="asset/style.css">

</head>

<body>
<div class="topbar animated fadeInLeftBig"></div>

<!-- Header Starts -->
<div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-default navbar-fixed-top" role="navigation" id="top-nav">
          <div class="container">
            <div class="navbar-header">
              <!-- Logo Starts -->
              <a class="navbar-brand" href="#home"><img src="images/logo.png" alt="logo"></a>
              <!-- #Logo Ends -->


              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


           <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right">
                 <li class="active"><a href="#home">Home</a></li>
                 <li ><a href="<?php echo e(route('signin')); ?>">login</a></li>
                 <li ><a href="<?php echo e(route('create')); ?>">Signup</a></li>
                                 
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

      </div>
    </div>
<!-- #Header Starts -->




<div id="home">

<div id="contact" class="spacer">
<!--Contact Starts-->
<div class="container contactform center">
<h2 class="text-center  wowload fadeInUp">SIGNUP DETAILS</h2>
  <div class="row wowload fadeInLeftBig">      
      <div class="col-sm-6 col-sm-offset-3 col-xs-12">      
        <form action='<?php echo e(route("signup")); ?>' method="post" autocomplete="off">
                <fieldset>
      <span class="btmspace-15">LAST NAME</span>
           <input type="text" class="btmspace-15" name="lastname" id="lastname" placeholder="Last Name" value='<?php if(isset($lastname)): ?><?php echo e($lastname); ?><?php endif; ?>'>
     <?php if(isset($lastname_error)): ?>
      <b style="color:red"><?php echo e($lastname_error); ?></b>
      <?php endif; ?>
     <span class="btmspace-15">FIRST NAME</span>
      <input type="text" class="btmspace-15" name="firstname" id="firstname" placeholder="First Name" value='<?php if(isset($firstname)): ?><?php echo e($firstname); ?><?php endif; ?>'>
    <?php if(isset($firstname_error)): ?>
      <b style="color:red"><?php echo e($firstname_error); ?></b>
      <?php endif; ?>
     <span class="btmspace-15">EMAIL</span>
      <input type="email" class="btmspace-15" name="email" id="email" placeholder="Email" value='<?php if(isset($email)): ?><?php echo e($email); ?><?php endif; ?>'>
    <?php if(isset($email_error)): ?>
      <b style="color:red"><?php echo e($email_error); ?></b>
      <?php endif; ?>

      <?php if(isset($email_name)): ?>
      <b style="color:red"><?php echo e($email_name); ?></b>
      <?php endif; ?>
     <span class="btmspace-15">PHONE NO:</span>
      <input type="text" class="btmspace-15" name="phone" id="phone" placeholder="phone" value='<?php if(isset($phone)): ?><?php echo e($phone); ?><?php endif; ?>'>
    <?php if(isset($phone_error)): ?>
      <b style="color:red"><?php echo e($phone_error); ?></b>
      <?php endif; ?>

      <?php if(isset($phone_name)): ?>
      <b style="color:red"><?php echo e($phone_name); ?></b>
      <?php endif; ?>
     <span class="btmspace-15">USERNAME</span>
      <input type="text" class="btmspace-15" name="username" id="username" placeholder="Username" value='<?php if(isset($username)): ?><?php echo e($username); ?><?php endif; ?>'>
    <?php if(isset($username_error)): ?>
      <b style="color:red"><?php echo e($username_error); ?></b>
      <?php endif; ?>

      <?php if(isset($username_name)): ?>
      <b style="color:red"><?php echo e($username_name); ?></b>
      <?php endif; ?>
      
     <span class="btmspace-15">PASSWORD</span>
      <input type="password" class="btmspace-15" name="password" id="password" placeholder="Password">
     <?php if(isset($password_error)): ?>
      <b style="color:red"><?php echo e($password_error); ?></b>
      <?php endif; ?>
   <span class="btmspace-15">CONFIRM PASSWORD</span>
      <input type="password" class="btmspace-15" name="confirm_password" id="confirm_password" placeholder="Confirm Password" value='<?php if(isset($password_confirm_error)): ?><?php echo e($password_confirm_error); ?><?php endif; ?>'>
    <?php echo e($errors->has('password')?'Password is Required':''); ?>

     <span class="btmspace-15">ACCOUNT NAME</span>
      <input type="text" class="btmspace-15" name="account_name" id="account_name" placeholder="Account Name" value='<?php if(isset($account_name)): ?><?php echo e($account_name); ?><?php endif; ?>'>
     <?php if(isset($account_name_error)): ?>
      <b style="color:red"><?php echo e($account_name_error); ?></b>
      <?php endif; ?>
     <span class="btmspace-15">ACCOUNT NUMBER</span>
      <input type="text" class="btmspace-15" name="account_no" id="account_no" placeholder="Account Number" value='<?php if(isset($account_number)): ?><?php echo e($account_number); ?><?php endif; ?>'>
     <?php if(isset($account_number_error)): ?>
      <b style="color:red"><?php echo e($account_number_error); ?></b>
      <?php endif; ?>

      <?php if(isset($acct)): ?>
      <b style="color:red"><?php echo e($acct); ?></b>
      <?php endif; ?>
      
     <span class="btmspace-15">BANK NAME</span>
      <input type="text" class="btmspace-15" name="bank_name" id="bank_name" placeholder="Bank Name" value='<?php if(isset($bank_name)): ?><?php echo e($bank_name); ?><?php endif; ?>'>
     <?php if(isset($bank_name_error)): ?>
      <b style="color:red"><?php echo e($bank_name_error); ?></b>
      <?php endif; ?>
      <button type="submit" class="btn btn-default">Create</button>
    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>"> 
        <fieldset>
        </form>
      </div>
  </div>



</div>
</div>
<!--Contact Ends-->



<!-- Footer Starts -->
<div class="footer text-center spacer">
<p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-dribbble fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-linkedin fa-2x"></i></a> </p>
Copyright 2017 fastalert.com. All rights reserved.
</div>

<!-- jquery -->
<script src="asset/jquery.js"></script>

<!-- wow script -->
<script src="asset/wow/wow.min.js"></script>


<!-- boostrap -->
<script src="asset/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="asset/mobile/touchSwipe.min.js"></script>
<script src="asset/respond/respond.js"></script>

<!-- gallery -->
<script src="asset/gallery/jquery.blueimp-gallery.min.js"></script>

<!-- custom script -->
<script src="asset/script.js"></script>

</body>
</html>