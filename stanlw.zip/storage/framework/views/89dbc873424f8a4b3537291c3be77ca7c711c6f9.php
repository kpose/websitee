<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="asset/img/favicon.ico">

    <title>HOME</title>

    <!-- Bootstrap core CSS -->
    <link href="asset/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="asset/css/custom-animations.css" rel="stylesheet">
    <link href="asset/css/style.css" rel="stylesheet">


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="asset/js/ie10-viewport-bug-workaround.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

   
    <! -- ********** BLUE SECTION - PICTON ********** -->
    
    <! -- ********** BLUE SECTION - CURIOUS ********** -->
    <div id="curious">
    <li><a href="<?php echo e(route('logout')); ?>"><button class="btn btn-lg btn-info btn-register">LOGOUT</button></a></li>
        <div class="row nopadding">
            <div class="col-md-5 col-md-offset-1 mt">
                 <b style="color:#000">NO AVAILBALE GH, PLEASE ORDER SHORTLY</b>
            </div>
            
            <div class="col-md-6 pull-right">
                <img src="asset/img/shot03.png" class="img-responsive alignright" alt="" data-effect="slide-right">
            </div>
        </div><! --/row -->
    </div><! --/curious -->

   
    <! -- ********** FOOTER ********** -->
    
    <! -- ********** CREDITS ********** -->
    <div id="c">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3 centered">
                    <p>Copyright 2017 | dopecash.com</p>
                </div>
            </div>
        </div><! --/container -->
    </div><! --/C -->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="asset/js/jquery.min.js"></script>
    <script src="asset/js/bootstrap.min.js"></script>
    <script src="asset/js/retina-1.1.0.js"></script>
    <script src="asset/js/jquery.unveilEffects.js"></script>
  </body>
</html>
