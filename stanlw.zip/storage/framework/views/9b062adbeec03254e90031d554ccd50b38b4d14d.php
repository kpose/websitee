<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>FASTALERT</title>

<!-- Google fonts -->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>

<!-- font awesome -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

<!-- bootstrap -->
<link rel="stylesheet" href="asset/bootstrap/css/bootstrap.min.css" />

<!-- animate.css -->
<link rel="stylesheet" href="asset/animate/animate.css" />
<link rel="stylesheet" href="asset/animate/set.css" />

<!-- gallery -->
<link rel="stylesheet" href="asset/gallery/blueimp-gallery.min.css">

<!-- favicon -->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">


<link rel="stylesheet" href="asset/style.css">

</head>

<body>
<div class="topbar animated fadeInLeftBig"></div>

<!-- Header Starts -->
<div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-default navbar-fixed-top" role="navigation" id="top-nav">
          <div class="container">
            <div class="navbar-header">
              <!-- Logo Starts -->
              <b> <span>FAST</span><span style="color:#37B5D4">ALERT</span></b>
              <!-- #Logo Ends -->


              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>

            </div>


           <!-- Nav Starts -->
            <div class="navbar-collapse  collapse">
              <ul class="nav navbar-nav navbar-right">
                 <li class="active"><a href="#home">Home</a></li>
                 <li ><a href="<?php echo e(route('signin')); ?>">login</a></li>
                 <li ><a href="<?php echo e(route('create')); ?>">Signup</a></li>
                                 
              </ul>
            </div>
            <!-- #Nav Ends -->

          </div>
        </div>

      </div>
    </div>
<!-- #Header Starts -->




<div id="home">

<div id="contact" class="spacer">
<!--Contact Starts-->
<div class="container contactform center">
<h2 class="text-center  wowload fadeInUp">LOGIN DETAILS</h2>
  <div class="row wowload fadeInLeftBig">      
      <div class="col-sm-6 col-sm-offset-3 col-xs-12">      
             <form action='<?php echo e(route("signin")); ?>' method="post" autocomplete="off">
        <fieldset>
        <b>USERNAME:</b>
          <input class="btmspace-15" type="text" value="" placeholder="USERNAME" name="username"><br>
          <b>PASSWORD:</b>
          <input class="btmspace-15" type="password" value="" placeholder="PASSWORD" name="password"><br>
          <a href="<?php echo e(route('signup')); ?>">New Account</a><br>
          <button type="submit" value="submit">LOGIN</button><br><br><br><br>
          <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token" >
        </fieldset>
      </form>
      </div>
  </div>



</div>
</div>
<!--Contact Ends-->



<!-- Footer Starts -->
<div class="footer text-center spacer">
<p class="wowload flipInX"><a href="#"><i class="fa fa-facebook fa-2x"></i></a> <a href="#"><i class="fa fa-dribbble fa-2x"></i></a> <a href="#"><i class="fa fa-twitter fa-2x"></i></a> <a href="#"><i class="fa fa-linkedin fa-2x"></i></a> </p>
Copyright 2017 fastalert.com. All rights reserved.
</div>

<!-- jquery -->
<script src="asset/jquery.js"></script>

<!-- wow script -->
<script src="asset/wow/wow.min.js"></script>


<!-- boostrap -->
<script src="asset/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="asset/mobile/touchSwipe.min.js"></script>
<script src="asset/respond/respond.js"></script>

<!-- gallery -->
<script src="asset/gallery/jquery.blueimp-gallery.min.js"></script>

<!-- custom script -->
<script src="asset/script.js"></script>

</body>
</html>