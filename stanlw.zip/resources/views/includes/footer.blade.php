<!-- Footer Starts -->
<div class="footer navbar-fixed-bottom" style="background-color:#000" >
     Copyright 2017 4alertcash.   Designed By softloft
   </div>

<!-- # Footer Ends -->
